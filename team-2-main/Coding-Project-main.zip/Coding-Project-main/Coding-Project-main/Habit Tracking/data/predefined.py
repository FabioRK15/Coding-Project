predefined_good = [
    "Drink 1 liter of water",
    "Meditate 5 minutes",
    "Read 10 pages",
    "Stretch 5 minutes",
    "Clean your room",
    "Gym session",
    "Eat something healthy",
    "Learn 10 minutes",
    "Practice guitar",
    "Walk 5,000 steps",
    "Journal 2 minutes",
    "Cold shower",
    "Sleep before midnight",
    "No phone for 15 minutes after waking up"
]

predefined_bad = [
    "Smoking",
    "Junk food",
    "Staying up too late",
    "Phone overuse",
    "Skipping workouts",
    "Too much caffeine",
    "Scrolling social media",
    "Gaming too long",
    "Alcohol drinking",
    "Procrastinating",
    "Skipping skincare",
    "Negative self-talk"
]